The following corrections have been made in this database version, compared with the printed publication:

1. Class 3830: In the first exclusion, the word "metal" has been deleted from the text ("Manufacture of new final products from (whether or not self-produced) secondary metal raw materials [...]" ). This was an oversight.
[23.01.2009]


2. Class 1313: In the explanatory note, the last line item has been deleted (�silk-screen printing on textiles and wearing apparel�).
[03.09.2009]


3. Class 1811: In the explanatory note. the second line item has been replaced with �- printing directly onto textiles, plastic, glass, metal, wood and ceramics�. In the exclusions, the first line item has been deleted ( �- silk-screen printing on textiles and wearing apparel, see 1313�).
[03.09.2009]


4. Division 51: In the first sentence of the second paragraph, the word �overhaul� has been replaced with �repair�. The overhaul of aircraft and aircraft engines would be classified in class 3315, but is less relevant as an exclusion in this context.
The correct text now reads:
�This division excludes the repair of aircraft or aircraft engines (see class 3315) and ��
[29.10.2010]


5. Class 3315: In the explanatory note, the first exclusion has been changed from 3010 to 3011. The correct text now reads:
"- factory rebuilding of ships, see 3011"
[31.05.2011]
